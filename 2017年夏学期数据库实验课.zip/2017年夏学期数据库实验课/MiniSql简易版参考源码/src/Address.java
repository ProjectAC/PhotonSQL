
public class Address {
	String file;
	int fileOffset;
	int blockOffset;
}
