
public class Condition {

}
