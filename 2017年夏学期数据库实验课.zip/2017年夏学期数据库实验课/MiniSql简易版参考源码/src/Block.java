
public class Block {	
	String file;
	int fileOffset;
	int spaceUsed;
	boolean isDirty;
	
	byte[] data;
}
