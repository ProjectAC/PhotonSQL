import java.util.List;


public class Buffer {
	
	List<Block> buffer;
	
	boolean addBlock(Block b){return false;}
	
	boolean LRUreplace(Block b){return false;}
	
	boolean isDirty(Block b){return false;}
	
	boolean pin(Block b){return false;}
}
