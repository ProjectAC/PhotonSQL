
public class BPlusTree {

	class BPlusTreeNode{
		
		void add(Object data){};
		void delete(Object data){};
		
	}
	
	BPlusTreeNode root;
	
	Address search(Object searchKey){return null;}
	
	void split(BPlusTreeNode node){}
	
	void merge(BPlusTreeNode node1,BPlusTreeNode node2){}
	
}
